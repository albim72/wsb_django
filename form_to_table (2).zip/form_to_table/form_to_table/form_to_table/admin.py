from django.contrib import admin 
from .models import DataModel

admin.site.register(DataModel)
